// the action types will be added/removed as per need

export const STORE_AUTH = "STORE_AUTH";
export const CLEAR_AUTH = "CLEAR_AUTH";
