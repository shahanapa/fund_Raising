import React from "react";
import Feed from "./Feedback Cards";
import "./Feedback.css";
import Button from "./Buttons";

function Feedback() {
  return (
    <>
      <br />
      <br />
      <Button />
      <Feed />
    </>
  );
}

export default Feedback;
