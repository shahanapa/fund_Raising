import React from "react";

const Tabbs = () => {
  return (
    <>
      <div className="container col-12 mb-0">
        <div class="tabContainer">
          <div class="buttonContainer">
            <button className="tab-btn-1">Activities</button>
            <button className="tab-btn-2">Requests</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Tabbs;
