import React from "react";

const Heading = () => {
  return (
    <>
      <div className="h1">
        <h1>Frequently asked Questions..!!!</h1>
      </div>
    </>
  );
};

export default Heading;
