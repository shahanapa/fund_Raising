import React from "react";
import "./Accordion.css";

const Bottom = () => {
  return (
    <>
      <div className="h4">
        <h4>Still Any Queries???</h4>
        <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Write to us at: email id</h4>
      </div>
    </>
  );
};

export default Bottom;
