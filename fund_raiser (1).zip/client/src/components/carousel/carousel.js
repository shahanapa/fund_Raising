import React from "react";
import Example from "./carousel.jsx";

const Carousel = () => {
  return (
    <>
      <Example />
    </>
  );
};

export default Carousel;
