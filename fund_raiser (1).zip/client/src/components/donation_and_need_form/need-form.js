import React from "react";
import Form2 from "./Form2";
import Heading2 from "./Heading2";
import Cover2 from "./Cover2";

// import Button from "./Button";

const Need = () => {
  return (
    <>
      <Heading2 />
      <Cover2 />
      <Form2 />
      {/* <Button /> */}
    </>
  );
};

export default Need;
