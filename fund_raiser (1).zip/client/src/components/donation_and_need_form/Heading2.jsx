import React from "react";

const Heading2 = () => {
  return (
    <>
      <div className="h1">
        <h1>We are here to lend a helping hand...</h1>
      </div>
    </>
  );
};

export default Heading2;
