import React from "react";

const Heading = () => {
  return (
    <>
      <div className="h1">
        <h1>No one has ever become poor by giving!!!</h1>
      </div>
    </>
  );
};

export default Heading;
