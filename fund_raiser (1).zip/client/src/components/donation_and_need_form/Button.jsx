import React from "react";

const Button = () => {
  return (
    <div>
      <button type="button" class="btn btn-warning">
        Submit for Approval
      </button>
    </div>
  );
};
export default Button;
