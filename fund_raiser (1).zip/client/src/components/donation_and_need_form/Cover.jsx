import React from "react";
import c2 from "./c2.png";

const Cover = () => {
  return (
    <>
      <img src={c2} className="img" alt="Donation Cover" />
    </>
  );
};

export default Cover;
