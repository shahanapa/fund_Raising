import React from "react";
import c1 from "./c1.png";

const Cover2 = () => {
  return (
    <>
      <img src={c1} className="img" alt="Need Form Cover" />
    </>
  );
};

export default Cover2;
